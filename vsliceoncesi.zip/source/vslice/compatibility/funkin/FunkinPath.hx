package vslice.compatibility.funkin;

import backend.CacheSystem;
import flixel.graphics.FlxGraphic;
import openfl.media.Sound;
import flixel.graphics.frames.FlxAtlasFrames;

class FunkinPath {

    public static function getPath(path:String,forceNative:Bool = false):String {
        #if MODS_ALLOWED
        if(forceNative) return Paths.getSharedPath(path);
        
        var curMod = Mods.currentModDirectory;
        var modsToCheck = Mods.getGlobalMods().copy();
        if(curMod != null && curMod != '') modsToCheck.insert(0,curMod);

        for (name in modsToCheck){
            var testPath = 'mods/$name/$path';
            if(NativeFileSystem.exists(testPath))
                return testPath;
        }
        if (NativeFileSystem.exists( 'mods/$path')) return 'mods/$path';
        else 
        #end
        return Paths.getSharedPath(path);
    }

    public static function sound(key:String):String {
        return key;//Paths.getPath("sounds/"+Language.getFileTranslation(key) + '.ogg', SOUND, null, true);
        //We'll handle this later in FunkinSound
    }
    public static function music(key:String):Sound {
        
        return Paths.music(key);
    }

    public static function image(s:String) {
        return Paths.image(s);
    }

    public static function getSparrowAtlas(s:String,?allowGPU:Bool = true):FlxAtlasFrames {
        return Paths.getSparrowAtlas(s,null,allowGPU);
    }

    public static function noGpuImage(s:String):FlxGraphic {
        return Paths.image(s,null,false);
    }

    public static function exists(s:String):Bool {
        // Check if a file exists somethere
        return Paths.fileExists(s,TEXT);
    }
    public static function stripLibrary(path:String):String
        {
          var parts:Array<String> = path.split(':');
          if (parts.length < 2) return path;
          return parts[1];
        }

    public static function clearUnusedMemory() { 
        CacheSystem.clearUnusedMemory();
    }
}
