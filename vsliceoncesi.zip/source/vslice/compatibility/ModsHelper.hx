package vslice.compatibility;

import backend.CacheSystem;
import openfl.filters.BitmapFilter;
import flixel.util.FlxSort;
import flixel.graphics.FlxGraphic;
import openfl.display.BitmapData;
import haxe.io.Path;

class ModsHelper {
	public inline static function isModDirEnabled(directory:String) {
		return Mods.parseList().enabled.contains(directory);
	}
    public inline static function loadModDir(directory:String) {
		Mods.currentModDirectory = directory;
	}
	public static function setDirectoryFromWeek(?data:backend.WeekData = null) {
		loadModDir('');
		if(data != null && data.folder != null && data.folder.length > 0) {
			loadModDir(data.folder);
		}
	}
	public inline static function getActiveMod():String {
		return Mods.currentModDirectory;
	}
	public inline static function getGlobalMods():Array<String> {
		return Mods.getGlobalMods();
	}
	public inline static function resetActiveMods() {
		#if MODS_ALLOWED
		Mods.pushGlobalMods();
		#end
		Mods.loadTopMod();
	}
	public static function getModsWithPlayersRegistry():Array<String> {
		#if MODS_ALLOWED
		return Mods.parseList().enabled.filter(s ->{
			var mod_path = Paths.mods(s)+'/registry/players';
			return NativeFileSystem.exists(mod_path) && 
				NativeFileSystem.readDirectory(mod_path).filter(s -> s.endsWith(".json")).length > 0;
		});
		#else
		return [];
		#end
	}

	public inline static function getSoundChannel(sound:FlxSound){
		@:privateAccess
		return sound._channel.__audioSource;
	}
	public inline static function setFiltersOnCam(camera:FlxCamera,value:Array<BitmapFilter>){
		camera.filters = value;
		camera.filtersEnabled = true;
	}
	public static function clearStoredWithoutStickers() {
		//! Doesn't actually clear the stickers
		@:privateAccess
		var cache = FlxG.bitmap._cache;
		for (key => val in cache){
			if(	key.toLowerCase().contains("transitionswag") || 
				key.contains("bg_graphic_") ||
				key == "images/justBf.png"
			) CacheSystem.currentTrackedAssets.set(key,val);
		}
		CacheSystem.clearStoredMemory();
		cacheStickersToContext();
	}
	public static function cacheStickersToContext() {
		for (key => val in CacheSystem.currentTrackedAssets){
			if(	key.toLowerCase().contains("transitionswag") || 
				key.contains("bg_graphic_") ||
				key == "images/justBf.png"
			) CacheSystem.localTrackedAssets.push(key);
		}
	}
	#if sys
	public inline static function collectVideos():String{
		var dirsToList = new Array<String>();
		dirsToList.push('assets/videos/commercials/');
		if(NativeFileSystem.exists('mods/videos/commercials'))dirsToList.push('mods/videos/commercials/');
		Mods.loadTopMod();
		var modsToSearch = Mods.getGlobalMods();
		modsToSearch.pushUnique(Mods.currentModDirectory);
		modsToSearch = modsToSearch.filter(s -> NativeFileSystem.exists('mods/$s/videos/commercials')).map(s -> 'mods/$s/videos/commercials');
		
		dirsToList = dirsToList.concat(modsToSearch);
		var commercialsToSelect = new Array<String>();
		for(potencialComercials in dirsToList){
		  for (file in NativeFileSystem.readDirectory(potencialComercials).filter(s -> s.endsWith(".mp4"))) {
			commercialsToSelect.push(potencialComercials + '/'+file);
		  }
		}
		return FlxG.random.getObject(commercialsToSelect);
	  }
	#end
}
