package backend;

#if sys
import sys.io.File;
import sys.FileSystem;
#end
import haxe.Json;

/**
 * PolymodHandler — Further-Engine'e V-Slice (Polymod) mod desteği katan
 * sadeleştirilmiş Polymod entegrasyonu.
 *
 * Resmi V-Slice'ın `source/funkin/modding/PolymodHandler.hx` dosyasından uyarlandı.
 * Amaç, Psych Engine'in mevcut mod sistemiyle YAN YANA çalışması:
 *   - Psych asset override'ı kendi `modFolders()` mekanizmasıyla yapılır (buna
 *     dokunmuyoruz — V-Slice asset modları zaten çalışır).
 *   - Polymod burada yalnızca: (1) `_polymod_meta.json` taraması, (2) api_version
 *     doğrulaması, (3) ZIP mod dosyalarını açma, (4) gelecekte `.hxc` scripted
 *     sınıf yüklemesi için altyapı sağlar.
 *
 * modRoot, Psych'in `Paths.mods()` mantığıyla aynı konumu kullanır
 * (Android'de dış depolama, masaüstünde Sys.getCwd()).
 */
class PolymodHandler
{
	/**
	 * Hangi V-Slice API sürümlerine izin vereceğimiz. Şu an resmi V-Slice 0.8.x.
	 * Geliştirme sırasında en gevşek kural olan "*" ile başlamanı öneririm;
	 * kendi modlarını döngüye aldığında `>=0.8.0 <0.9.0` gibi katılaştır.
	 */
	public static final API_VERSION_RULE:String = '*';

	/**
	 * Polymod'un kullandığı haxelib sürümüne göre gerçek sınıf adı.
	 * "polymod" kütüphanesi için haxelib kurulduktan sonra derleyici bunu çözer.
	 */
	static final MOD_FOLDER:String = #if android StorageUtil.getExternalStorageDirectory() + #else Sys.getCwd() + #end 'mods';

	/** Başarıyla yüklenen V-Slice modlarının dizin adları. */
	public static var loadedModDirs:Array<String> = [];

	/** Başarıyla yüklenen V-Slice modlarının id'leri. */
	public static var loadedModIds:Array<String> = [];

	/** Polymod bir kez init edildi mi? */
	static var initialized:Bool = false;

	/**
	 * Polymod'u yapılandırır (henüz mod yüklemez). `Main.hx` içinde, mevcut
	 * `Mods.pushGlobalMods()` / `Mods.loadTopMod()` çağrılarının yanında çalıştırılır.
	 */
	public static function init():Void
	{
		#if sys
		if (!FileSystem.exists(MOD_FOLDER)) FileSystem.createDirectory(MOD_FOLDER);
		#end

		#if POLYMOD_ALLOWED
		// Polymod, OPENFL framework'ü üzerinden asset override yapar.
		// NOT: Psych zaten kendi modFolders() mekanizmasıyla asset çözümlediği için,
		// burada yalnızca scripted class altyapısını ve metadata taramasını kuruyoruz.
		var result = polymod.Polymod.init({
			modRoot: MOD_FOLDER,
			dirs: [],
			framework: OPENFL,
			apiVersionRule: API_VERSION_RULE,
			errorCallback: onPolymodError,
			// ZIP modların açılabilmesi için default'un dışında ZipFileSystem de tanımlanabilir.
			// İleriki aşamada: customFilesystem = new polymod.fs.ZipFileSystem({modRoot: MOD_FOLDER, autoScan: true}),
			skipDependencyErrors: true,
			loadScriptsAsync: false,
			useScriptedClasses: false // Aşama 3'te .hxc desteği gelince true yap
		});

		loadedModDirs = [];
		loadedModIds = [];
		if (result != null)
		{
			for (mod in result)
			{
				trace('[Polymod] Yüklendi: ${mod.title} v${mod.modVersion} [${mod.id}]');
				loadedModDirs.push(mod.dirName);
				loadedModIds.push(mod.id);
			}
		}
		initialized = true;
		#end
	}

	/**
	 * `mods/` klasöründeki `_polymod_meta.json` içeren tüm V-Slice modlarını
	 * (dizin adlarını) listeler. API_VERSION_RULE ile uyumsuz olanları atlar.
	 */
	public static function scanModDirs():Array<String>
	{
		var dirs:Array<String> = [];

		#if POLYMOD_ALLOWED
		if (!initialized) init();

		var metadata:Array<Dynamic> = polymod.Polymod.scan({
			modRoot: MOD_FOLDER,
			apiVersionRule: API_VERSION_RULE,
			errorCallback: onPolymodError
		});

		for (mod in metadata)
		{
			var dir:String = mod.dirName;
			if (dir == null || dir.length < 1) continue;
			if (!dirs.contains(dir)) dirs.push(dir);
		}
		#end
		return dirs;
	}

	/**
	 * Bir V-Slice modunu (dizin adıyla) yükler. Polymod modları "enable" olarak işaretler;
	 * Psych tarafında `Mods.loadTopMod()` / `modsList.txt` ile senkronize edilir.
	 */
	public static function loadMod(dir:String):Bool
	{
		#if POLYMOD_ALLOWED
		var result = polymod.Polymod.init({
			modRoot: MOD_FOLDER,
			dirs: [dir],
			framework: OPENFL,
			apiVersionRule: API_VERSION_RULE,
			errorCallback: onPolymodError,
			skipDependencyErrors: true,
			loadScriptsAsync: false,
			useScriptedClasses: false
		});
		return result != null && result.length > 0;
		#else
		return false;
		#end
	}

	/**
	 * Metadata yeniden yükleme / hot-reload noktası. Modları yeniden tarar.
	 * Aşama 4'teki "Reload" butonu burayı çağırır.
	 */
	public static function forceReload():Void
	{
		#if POLYMOD_ALLOWED
		polymod.Polymod.clearScripts();
		#end
		initialized = false;
		scanModDirs();
	}

	static function onPolymodError(error:String):Void
	{
		trace('[Polymod] Hata: $error');
	}
}
